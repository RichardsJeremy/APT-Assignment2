#ifndef NODE
#define NODE

#include <memory>

class node
{
public:
    node(int data, std::shared_ptr<node> next);
    ~node();

    std::shared_ptr<node> next;
    int data;
};
#endif