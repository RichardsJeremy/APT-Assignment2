#ifndef LINKED_LIST
#define LINKED_LIST

#include "node.cpp"
#include <iostream>

class linkedList
{
private:
    /* data */
public:
    linkedList(/* args */);
    ~linkedList();
    void clear();
    void addPosition(int i, int data);
    void addFront(int data);
    void deleteFront();
    void deletePosition(int pos);
    void addBack(int data);
    void deleteBack();
    void displayList();
    int getSize();

    std::shared_ptr<node> head = nullptr;
    std::shared_ptr<node> tail = nullptr;
    int sizeCounter = 0;
};

#endif