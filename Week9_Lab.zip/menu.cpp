#include "menu.hpp"

menu::menu()
{
    std::shared_ptr<linkedList> p2 = std::make_shared<linkedList>();
    this->linkedListptr = p2;
}

menu::~menu()
{
}

void menu::printMenu()
{
    std::cout << "Linked List Demo"
              << "\n"
              << "----" 
              << "\n"
              << "1. Display List\n"
              << "2. Add Front\n"
              << "3. Add Back\n"
              << "4. Delete Front\n"
              << "5. Delete Back\n"
              << "6. Add Position\n"
              << "7. Delete Position\n"
              << "8. Quit\n";
}

void menu::runMenu()
{
    int choice = 0;
    do
    {
        printMenu();
        std::cout << "\n";
        std::cin >> choice;
        choose(choice);
    }
    

    while (choice != 8);
    std::cout << "\n";
}

void menu::choose(int choice) {

    if(choice == 1) {
        linkedListptr->displayList();
        std::cout << "\n";
    }
    else if (choice == 2)
    {
        std::cout << "Enter a value to be added.\n";
        int value = 0;
        std::cin >> value;
        linkedListptr->addFront(value);
        std::cout << "\n";
    }
    else if (choice == 3)
    {
        std::cout << "Enter a value to be added.\n";
        int value = 0;
        std::cin >> value;
        linkedListptr->addBack(value);
        std::cout << "\n";
    }
    else if (choice == 4)
    {
        std::cout << "Value at Position 1 has been deleted.\n";
        linkedListptr->deleteFront();
    }
    else if (choice == 5)
    {
        std::cout << "Value at Position "<< linkedListptr->getSize() <<" has been deleted.\n";
        linkedListptr->deleteBack();
    }
    else if (choice == 6)
    {
        std::cout << "Enter a value to be added.\n";
        int value = 0;
        std::cin >> value;
        std::cout << "\nEnter a position.\n";
        int pos = 0;
        std::cin >> pos;
        linkedListptr->addPosition(pos,value);
        std::cout << "\n";
    }
    else if (choice == 7)
    {
        std::cout << "Enter a position to be deleted.\n";
        int value = 0;
        std::cin >> value;
        linkedListptr->deletePosition(value);
        std::cout << "\n";
    }
    else if (choice == 8) {
        std::cout << "goodbye!!\n\n";
    }
    else
    {
        std::cout << "Please Enter a Valid Option\n";
    }
    
}