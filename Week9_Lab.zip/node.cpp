#include "node.hpp"

node::node(int _data, std::shared_ptr<node> _next)
{
    this->data = _data;
    this->next = _next;
}

node::~node()
{
}