#include "menu.cpp"
#include "iostream"

#define EXIT_SUCCESS 0

int main()
{
    std::shared_ptr<menu> menuob = std::make_shared<menu>();
    menuob->runMenu();

    return EXIT_SUCCESS;
}