#ifndef MENU
#define MENU

#include "linkedList.cpp"
#include <iostream>

class menu
{
public:
    menu();
    ~menu();
    void printMenu();
    void runMenu();
    void choose(int choice);

    std::shared_ptr<linkedList> linkedListptr;
};
#endif