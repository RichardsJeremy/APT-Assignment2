#include "linkedList.hpp"

linkedList::linkedList(){

}


linkedList::~linkedList() {
    clear();
}

int linkedList::getSize() {
    return sizeCounter;
}

void linkedList::clear() {

    //loop to iterate through and delete all nodes starting from head
    while (head->next != nullptr)
    {
        std::shared_ptr<node> tempDelete = head;
        head = head->next;
    }
    //reset everything to default for new list
    std::shared_ptr<node> deleteHead = head;
    head = nullptr;
    tail = nullptr;
    sizeCounter = 0;
}

void linkedList::displayList() {

    //node to cycle through and print data
    std::shared_ptr<node> currentNode = head;

    if (sizeCounter == 0)
    {
        std::cout << "The list is empty.\n\n";
    }
    else
    {
        for (int i = 0; i < sizeCounter; i++)
        {
            std::cout << "Element at position: " << i + 1 << " is " << currentNode->data << ".\n\n";
            currentNode = currentNode->next;
        }
    }
}

void linkedList::addPosition(int pos, int data) {
    std::shared_ptr<node> currentNode = head;

    if (pos > sizeCounter)
    {
        std::cerr << "Error: the list is not that big\n";
    }
    else
    {   
        for (int i = 1; i < pos - 1; i++)
        {
            currentNode = currentNode->next;
        }
    std::shared_ptr<node> newNode = std::make_shared<node>(data, currentNode->next);
    currentNode->next = newNode;
    sizeCounter++;
    }
}

void linkedList::deletePosition(int pos) {
    if (pos > sizeCounter)
    {
        std::cerr << "Error: the list is not that big\n";
    }
    else
    {
        
    }
}

void linkedList::addFront(int data) {
    if (sizeCounter == 0)
    {
        std::shared_ptr<node> newNode = std::make_shared<node>(data, nullptr);
        head = newNode;
        tail = newNode;
    }
    else
    {
        std::shared_ptr<node> newNode = std::make_shared<node>(data, head);
        head = newNode;
    }
    sizeCounter++;
}

void linkedList::deleteFront() {
    std::shared_ptr<node> tempDel = head;
    head = head->next;
    sizeCounter--;
}

void linkedList::addBack(int data) {
    std::shared_ptr<node> changeMe = tail;

    if (sizeCounter == 0)
    {
        
        std::shared_ptr<node> newNode = std::make_shared<node>(data, nullptr);
        head = newNode;
        tail = newNode;
    }
    else
    {
        std::shared_ptr<node> newNode = std::make_shared<node>(data, nullptr);
        changeMe->next = newNode;
        tail = newNode;
    }
    sizeCounter++;
}

void linkedList::deleteBack() {
    std::shared_ptr<node> newTail = head;
    std::shared_ptr<node> deleteMe = tail;

    for (int i = 1; i < sizeCounter - 1; i++)
    {
        newTail = newTail->next;
    }
    
    tail = newTail;
    newTail->next = nullptr;
    sizeCounter--;
    
}